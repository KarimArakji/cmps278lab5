function getSize() {
    slider = document.getElementById("slider");
    return slider.value;
}

function getMeat() {
    var arrayy = []
    if (document.getElementById("Pepperoni").checked) {
        arrayy.push(document.getElementById("Pepperoni").id)
    }
    if (document.getElementById("Sausage").checked) {
        arrayy.push(document.getElementById("Sausage").id)
    }
    if (document.getElementById("GroundBeef").checked) {
        arrayy.push(document.getElementById("GroundBeef").id)
    }
    if (document.getElementById("Anchovy").checked) {
        arrayy.push(document.getElementById("Anchovy").id)
    }
    if (document.getElementById("Chicken").checked) {
        arrayy.push(document.getElementById("Chicken").id)
    }

    return arrayy;
}


function getVeg() {
    var arrayy = []
    if (document.getElementById("Tomatoes").checked) {
        arrayy.push(document.getElementById("Tomatoes").id)
    }
    if (document.getElementById("Onions").checked) {
        arrayy.push(document.getElementById("Onions").id)
    }
    if (document.getElementById("Olives").checked) {
        arrayy.push(document.getElementById("Olives").id)
    }
    if (document.getElementById("Mushrooms").checked) {
        arrayy.push(document.getElementById("Mushrooms").id)
    }
    if (document.getElementById("Pineapple").checked) {
        arrayy.push(document.getElementById("Pineapple").id)
    }
    if (document.getElementById("Spinach").checked) {
        arrayy.push(document.getElementById("Spinach").id)
    }
    if (document.getElementById("Jalapeno").checked) {
        arrayy.push(document.getElementById("Jalapeno").id)
    }

    return arrayy;
}

function getCheese() {
    if (document.getElementById("RegularCheese").checked) {
        return 1;
    } else if (document.getElementById("NoCheese").checked) {
        return 2;
    } else if (document.getElementById("ExtraCheese").checked) {
        return 3;
    }
}

function ChangePizzaSize() {

    var cost = 0;

    if (document.getElementById("slider").value == "1") {
        document.getElementById("pizzaImage").style.width = "100px";
        document.getElementById("Cost").innerHTML = "Small $6";
        cost += 6;
    } else if (document.getElementById("slider").value == "2") {
        document.getElementById("pizzaImage").style.width = "150px";
        document.getElementById("Cost").innerHTML = "Medium $10";
        cost += 10;
    } else if (document.getElementById("slider").value == "3") {
        document.getElementById("pizzaImage").style.width = "200px";
        document.getElementById("Cost").innerHTML = "Large $14";
        cost += 14;
    } else if (document.getElementById("slider").value == "4") {
        document.getElementById("pizzaImage").style.width = "250px";
        document.getElementById("Cost").innerHTML = "X-Large $16";
        cost += 16;
    }

    return cost;
}

function calculateTotal() {

    var Total = 0;
    Total += ChangePizzaSize();
    Total += getMeat().length * 2;
    Total += getVeg().length;
    if (getCheese() == 3) {
        Total += 3;
    }
    return Total

}

function fillSummary() {


    var array1 = getVeg();
    var array2 = getMeat();
    var sizee = getSize();


    if (sizee == "1") {
        document.getElementById("orderList").innerHTML += ('<li>' + "Small size" + '</li>');
    } else if (sizee == "2") {
        document.getElementById("orderList").innerHTML += ('<li>' + "Medium size" + '</li>');
    } else if (sizee == "3") {
        document.getElementById("orderList").innerHTML += ('<li>' + "Large Size" + '</li>');
    } else if (size == "4") {
        document.getElementById("orderList").innerHTML += ('<li>' + "X-Large Size" + '</li>');
    }


    var m = document.getElementById("CityName");
    var fullSTrD = "";
    fullSTrD += document.getElementById("FirstName").value + " ";
    fullSTrD += document.getElementById("LastName").value + ", ";
    fullSTrD += document.getElementById("Email").value + ", ";
    fullSTrD += "Phone Number:" + document.getElementById("Phone").value + ", ";
    fullSTrD += m.options[m.selectedIndex].text + " - ";
    fullSTrD += document.getElementById("Address").value;

    document.getElementById("dlvrTo").innerHTML = fullSTrD;



    document.getElementById("orderList").innerHTML += ('<li>' + array2.pop() + '</li>');
    document.getElementById("orderList").innerHTML += ('<li>' + array1.pop() + '</li>');


}